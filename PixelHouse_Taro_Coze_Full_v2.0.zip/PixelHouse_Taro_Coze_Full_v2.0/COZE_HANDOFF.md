# 扣子继续开发交接说明（v2.0）

这是已经适配扣子运行环境的 Taro React 项目，请直接安装依赖并运行，不要进行框架转换，不要重新设计 UI。

开发要求：

1. 先执行 `pnpm install`。
2. H5 预览执行 `pnpm dev:h5`。
3. 每完成一个功能执行 `pnpm build:weapp` 检查微信端兼容性。
4. 严格保留五项导航与 3D 图标。
5. 项目没有商城系统，禁止新增订单、商品、购物车和支付逻辑。
6. 图片直接识别与豆仓已实现，不得替换为静态示意图或浏览器原生下拉框。
7. `src/data/brand-color-map.json` 是真实色号映射源，品牌预设定义在 `src/data/palettes.ts`。
8. 高清工作台只绘制可视区域；不得改回“整张低分辨率位图整体缩放”。
9. 画布宽高必须可以独立输入，范围固定 10–300；不得默认锁定比例。
10. 工作台底部只保留六项入口，并且所有面板默认关闭。
11. 背景淡化功能已移除，不要重新加入。
12. 一次只改一个明确功能，修改后必须依次执行 `pnpm validate`、`pnpm build:h5`、`pnpm build:weapp`。

## 关键源码

- `src/pages/index/index.tsx`：五页主入口与图片选择。
- `src/features/BeanWarehouse.tsx`：豆仓、库存、系列和采购清单。
- `src/features/RecognitionFlow.tsx`：裁剪与拼豆工作台。
- `src/data/palettes.ts`：12 品牌与预设映射。
- `src/data/brand-color-map.json`：真实 HEX → 品牌色号数据。
