# 构建验证

- 项目版本：2.0.0
- 验证日期：2026-08-16
- Node.js：18 或更高
- 包管理器：pnpm

已通过：

```bash
pnpm validate
pnpm build:h5
pnpm build:weapp
```

构建产物：

- H5：`dist/h5`
- 微信小程序：`dist/weapp`

H5 构建只有 Webpack 的推荐体积提示，不影响运行；TypeScript 与微信小程序构建均无错误。
