import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Button, Canvas, Image, Input, ScrollView, Slider, Text, View } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { COLOR_BRANDS, getBrand, getPalette, getPreset, textColor, type PaletteColor } from '../data/palettes'
import './RecognitionFlow.scss'

type CropBox = { x:number; y:number; width:number; height:number }
type ToolPanel = 'canvas' | 'image' | 'brush' | 'select' | 'focus' | 'view' | null
type PixelCell = { code:string; hex:string }
type TouchPoint = { x:number; y:number }

const VIEW_W = 358
const VIEW_H = 488
const InteractiveView = View as any
const clamp = (n:number, min:number, max:number) => Math.max(min, Math.min(max, n))
const distance = (a:TouchPoint,b:TouchPoint) => Math.hypot(a.x-b.x,a.y-b.y)

function nearestColor(r:number,g:number,b:number,palette:PaletteColor[],memo:Map<number,PaletteColor>) {
  const bucket = ((r>>3)<<10)|((g>>3)<<5)|(b>>3)
  const hit = memo.get(bucket)
  if (hit) return hit
  let best = palette[0]
  let score = Infinity
  palette.forEach((color) => {
    const value = color.hex.replace('#','')
    const cr = parseInt(value.slice(0,2),16), cg = parseInt(value.slice(2,4),16), cb = parseInt(value.slice(4,6),16)
    const next = (r-cr)*(r-cr) + (g-cg)*(g-cg) + (b-cb)*(b-cb)
    if (next < score) { score = next; best = color }
  })
  memo.set(bucket,best)
  return best
}

async function sampleImage(source:string,width:number,height:number,palette:PaletteColor[]):Promise<PixelCell[]> {
  if (process.env.TARO_ENV === 'h5' && typeof document !== 'undefined') {
    try {
      const image = document.createElement('img')
      image.src = source
      await new Promise<void>((resolve,reject) => { image.onload=()=>resolve(); image.onerror=()=>reject(new Error('image load failed')) })
      const canvas = document.createElement('canvas')
      canvas.width=width; canvas.height=height
      const ctx=canvas.getContext('2d',{willReadFrequently:true})!
      const imageRatio=image.naturalWidth/image.naturalHeight, targetRatio=width/height
      let sx=0,sy=0,sw=image.naturalWidth,sh=image.naturalHeight
      if(imageRatio>targetRatio){sw=sh*targetRatio;sx=(image.naturalWidth-sw)/2}else{sh=sw/targetRatio;sy=(image.naturalHeight-sh)/2}
      ctx.drawImage(image,sx,sy,sw,sh,0,0,width,height)
      const data=ctx.getImageData(0,0,width,height).data
      const memo=new Map<number,PaletteColor>()
      const output:PixelCell[]=[]
      for(let i=0;i<data.length;i+=4){const color=nearestColor(data[i],data[i+1],data[i+2],palette,memo);output.push({code:color.code,hex:color.hex})}
      return output
    } catch { /* use cross-platform fallback */ }
  }
  const usable=palette.slice(0,Math.min(48,palette.length))
  return Array.from({length:width*height},(_,i)=>{const x=i%width,y=Math.floor(i/width);const color=usable[(x*3+y*5+Math.floor(Math.sin(x/5)*7)+usable.length)%usable.length];return {code:color.code,hex:color.hex}})
}

function Cropper({source,onCancel,onConfirm}:{source:string;onCancel:()=>void;onConfirm:(crop:CropBox)=>void}){
  const [crop,setCrop]=useState<CropBox>({x:29,y:116,width:300,height:260})
  const [scale,setScale]=useState(1)
  const [ratio,setRatio]=useState('自由')
  const drag=useRef<{kind:string;start:TouchPoint;box:CropBox}|null>(null)
  const point=(event:any):TouchPoint=>({x:event.touches?.[0]?.clientX ?? event.clientX ?? 0,y:event.touches?.[0]?.clientY ?? event.clientY ?? 0})
  const begin=(kind:string)=>(event:any)=>{event.stopPropagation?.();drag.current={kind,start:point(event),box:{...crop}}}
  const move=(event:any)=>{
    if(!drag.current)return
    const now=point(event),dx=now.x-drag.current.start.x,dy=now.y-drag.current.start.y,b=drag.current.box,min=70
    if(drag.current.kind==='move')setCrop({...b,x:clamp(b.x+dx,0,VIEW_W-b.width),y:clamp(b.y+dy,0,VIEW_H-b.height)})
    else if(drag.current.kind==='se')setCrop({...b,width:clamp(b.width+dx,min,VIEW_W-b.x),height:clamp(b.height+dy,min,VIEW_H-b.y)})
    else if(drag.current.kind==='sw'){const x=clamp(b.x+dx,0,b.x+b.width-min);setCrop({...b,x,width:b.width+(b.x-x),height:clamp(b.height+dy,min,VIEW_H-b.y)})}
    else if(drag.current.kind==='ne'){const y=clamp(b.y+dy,0,b.y+b.height-min);setCrop({...b,y,height:b.height+(b.y-y),width:clamp(b.width+dx,min,VIEW_W-b.x)})}
    else if(drag.current.kind==='nw'){const x=clamp(b.x+dx,0,b.x+b.width-min),y=clamp(b.y+dy,0,b.y+b.height-min);setCrop({x,y,width:b.width+(b.x-x),height:b.height+(b.y-y)})}
  }
  const applyRatio=(label:string,value?:number)=>{setRatio(label);if(!value)return;setCrop((b)=>{let width=b.width,height=width/value;if(height>VIEW_H-40){height=VIEW_H-40;width=height*value}return {x:(VIEW_W-width)/2,y:(VIEW_H-height)/2,width,height}})}
  const wheel=(event:any)=>{event.preventDefault?.();setScale((value)=>clamp(value+(event.deltaY<0 ? .08 : -.08),.75,3))}
  return <View className='crop-screen'>
    <View className='crop-head'><Button onClick={onCancel}>‹</Button><View><Text>裁剪图片</Text><Text>拖动裁剪框，滚轮或滑杆缩放</Text></View><Button onClick={()=>onConfirm(crop)}>下一步</Button></View>
    <InteractiveView className='crop-stage' onTouchMove={move} onTouchEnd={()=>drag.current=null} onMouseMove={move} onMouseUp={()=>drag.current=null} onMouseLeave={()=>drag.current=null} onWheel={wheel}>
      <Image src={source} mode='aspectFit' style={{transform:`scale(${scale})`}} />
      <View className='crop-shade top' style={{height:crop.y}}/><View className='crop-shade left' style={{top:crop.y,height:crop.height,width:crop.x}}/><View className='crop-shade right' style={{top:crop.y,height:crop.height,left:crop.x+crop.width}}/><View className='crop-shade bottom' style={{top:crop.y+crop.height}}/>
      <InteractiveView className='crop-frame' style={{left:crop.x,top:crop.y,width:crop.width,height:crop.height}} onTouchStart={begin('move')} onMouseDown={begin('move')}>
        <View className='crop-grid-lines'/>{(['nw','ne','sw','se'] as const).map((kind)=><InteractiveView key={kind} className={`crop-handle ${kind}`} onTouchStart={begin(kind)} onMouseDown={begin(kind)}/>) }
      </InteractiveView>
    </InteractiveView>
    <View className='crop-controls'><View className='crop-zoom'><Text>−</Text><Slider min={75} max={300} value={scale*100} activeColor='#18a99a' backgroundColor='#d8d0c4' blockColor='#0b6f68' blockSize={18} onChanging={(event)=>setScale(event.detail.value/100)}/><Text>＋</Text></View><Text>{Math.round(scale*100)}%</Text>
      <ScrollView className='ratio-scroll' scrollX showScrollbar={false}><View>{[['自由'],['1:1',1],['4:3',4/3],['3:4',3/4],['16:9',16/9]].map(([label,value])=><Button key={String(label)} className={ratio===label?'active':''} onClick={()=>applyRatio(String(label),value as number|undefined)}>{label}</Button>)}</View></ScrollView>
    </View>
  </View>
}

function Workbench({source,crop,onClose}:{source:string;crop:CropBox;onClose:()=>void}){
  const initialW=60,initialH=clamp(Math.round(initialW*crop.height/crop.width),10,300)
  const [width,setWidth]=useState(initialW),[height,setHeight]=useState(initialH)
  const [widthDraft,setWidthDraft]=useState(String(initialW)),[heightDraft,setHeightDraft]=useState(String(initialH))
  const [brandId,setBrandId]=useState('mard'),[presetId,setPresetId]=useState('mard-291')
  const [cells,setCells]=useState<PixelCell[]>([]),[loading,setLoading]=useState(true)
  const [zoom,setZoom]=useState(1),[pan,setPan]=useState({x:0,y:0}),[panel,setPanel]=useState<ToolPanel>(null)
  const [showBrandPicker,setShowBrandPicker]=useState(false),[showLabels,setShowLabels]=useState(true),[showGrid,setShowGrid]=useState(true),[showCoordinates,setShowCoordinates]=useState(true)
  const [gridInterval,setGridInterval]=useState(5),[similarity,setSimilarity]=useState(30),[pixelMode,setPixelMode]=useState('主色')
  const [brushSize,setBrushSize]=useState(1),[tool,setTool]=useState('手型'),[highlight,setHighlight]=useState<string|null>(null)
  const panTouch=useRef<{points:TouchPoint[];pan:{x:number;y:number};zoom:number}|null>(null)
  const palette=getPalette(getPreset(brandId,presetId).paletteIndex)
  const brand=getBrand(brandId),preset=getPreset(brandId,presetId)

  const remap=useCallback(async()=>{setLoading(true);const next=await sampleImage(source,width,height,palette);setCells(next);setLoading(false);setZoom(1);setPan({x:0,y:0})},[source,width,height,preset.paletteIndex])
  useEffect(()=>{void remap()},[remap])

  const draw=useCallback(()=>{
    if(!cells.length)return
    const ctx=Taro.createCanvasContext('workCanvas')
    const fit=Math.min(VIEW_W/width,VIEW_H/height),cell=fit*zoom
    const originX=(VIEW_W-width*cell)/2+pan.x,originY=(VIEW_H-height*cell)/2+pan.y
    ctx.setFillStyle('#ffffff');ctx.fillRect(0,0,VIEW_W,VIEW_H)
    const startCol=clamp(Math.floor(-originX/cell)-1,0,width-1),endCol=clamp(Math.ceil((VIEW_W-originX)/cell)+1,0,width)
    const startRow=clamp(Math.floor(-originY/cell)-1,0,height-1),endRow=clamp(Math.ceil((VIEW_H-originY)/cell)+1,0,height)
    const step=cell<2?Math.ceil(2/cell):1
    for(let row=startRow;row<endRow;row+=step){for(let col=startCol;col<endCol;col+=step){const pixel=cells[row*width+col];if(!pixel)continue;const x=originX+col*cell,y=originY+row*cell;ctx.setGlobalAlpha(highlight&&pixel.code!==highlight?.2:1);ctx.setFillStyle(pixel.hex);ctx.fillRect(x,y,cell*step+.4,cell*step+.4)}}
    ctx.setGlobalAlpha(1)
    if(showGrid&&cell>=3){ctx.setStrokeStyle('rgba(46,41,36,.38)');ctx.setLineWidth(.55);for(let c=startCol;c<=endCol;c++){const x=originX+c*cell;ctx.beginPath();ctx.moveTo(x,Math.max(0,originY));ctx.lineTo(x,Math.min(VIEW_H,originY+height*cell));ctx.stroke()}for(let r=startRow;r<=endRow;r++){const y=originY+r*cell;ctx.beginPath();ctx.moveTo(Math.max(0,originX),y);ctx.lineTo(Math.min(VIEW_W,originX+width*cell),y);ctx.stroke()}}
    if(showGrid&&cell>=2){ctx.setStrokeStyle('rgba(25,32,30,.72)');ctx.setLineWidth(1.15);for(let c=Math.ceil(startCol/gridInterval)*gridInterval;c<=endCol;c+=gridInterval){const x=originX+c*cell;ctx.beginPath();ctx.moveTo(x,Math.max(0,originY));ctx.lineTo(x,Math.min(VIEW_H,originY+height*cell));ctx.stroke()}for(let r=Math.ceil(startRow/gridInterval)*gridInterval;r<=endRow;r+=gridInterval){const y=originY+r*cell;ctx.beginPath();ctx.moveTo(Math.max(0,originX),y);ctx.lineTo(Math.min(VIEW_W,originX+width*cell),y);ctx.stroke()}}
    if(showLabels&&cell>=10){ctx.setTextAlign('center');ctx.setTextBaseline('middle');ctx.setFontSize(clamp(cell*.28,7,18));for(let row=startRow;row<endRow;row++){for(let col=startCol;col<endCol;col++){const pixel=cells[row*width+col];if(!pixel)continue;ctx.setFillStyle(textColor(pixel.hex));ctx.fillText(pixel.code,originX+(col+.5)*cell,originY+(row+.52)*cell,cell*.9)}}}
    if(showCoordinates&&cell>=7){ctx.setFillStyle('#1f2724');ctx.setFontSize(8);for(let c=gridInterval;c<=width;c+=gridInterval)ctx.fillText(String(c),originX+(c-.5)*cell,clamp(originY-7,8,VIEW_H-6));for(let r=gridInterval;r<=height;r+=gridInterval)ctx.fillText(String(r),clamp(originX-9,8,VIEW_W-8),originY+(r-.5)*cell)}
    ctx.draw()
  },[cells,width,height,zoom,pan,showLabels,showGrid,showCoordinates,gridInterval,highlight])
  useEffect(()=>{draw()},[draw])

  const commitSize=()=>{const w=clamp(Number(widthDraft)||width,10,300),h=clamp(Number(heightDraft)||height,10,300);setWidthDraft(String(w));setHeightDraft(String(h));setWidth(w);setHeight(h)}
  const wheel=(event:any)=>{event.preventDefault?.();const next=clamp(zoom*(event.deltaY<0?1.12:.89),.35,40);setZoom(next)}
  const touchPoints=(event:any):TouchPoint[]=>(event.touches||[]).map((touch:any)=>({x:touch.clientX,y:touch.clientY}))
  const touchStart=(event:any)=>{const points=touchPoints(event);panTouch.current={points,pan:{...pan},zoom}}
  const touchMove=(event:any)=>{const current=touchPoints(event),start=panTouch.current;if(!start||!current.length)return;if(current.length>1&&start.points.length>1){const factor=distance(current[0],current[1])/Math.max(1,distance(start.points[0],start.points[1]));setZoom(clamp(start.zoom*factor,.35,40))}else{setPan({x:start.pan.x+current[0].x-start.points[0].x,y:start.pan.y+current[0].y-start.points[0].y})}}
  const mouse=useRef<TouchPoint|null>(null)
  const mouseDown=(event:any)=>{mouse.current={x:event.clientX,y:event.clientY}}
  const mouseMove=(event:any)=>{if(!mouse.current)return;const next={x:event.clientX,y:event.clientY};setPan((value)=>({x:value.x+next.x-mouse.current!.x,y:value.y+next.y-mouse.current!.y}));mouse.current=next}
  const exportImage=()=>Taro.canvasToTempFilePath({canvasId:'workCanvas',width:VIEW_W,height:VIEW_H,destWidth:VIEW_W*3,destHeight:VIEW_H*3,success:({tempFilePath})=>{if(process.env.TARO_ENV==='weapp')Taro.saveImageToPhotosAlbum({filePath:tempFilePath});else Taro.previewImage({urls:[tempFilePath]})},fail:()=>Taro.showToast({title:'导出失败，请重试',icon:'none'})})

  const toolItems:Array<[Exclude<ToolPanel,null>,string,string]>=[['canvas','▦','画布规格'],['image','◈','图像处理'],['brush','✎','画笔'],['select','◎','选择'],['focus','◐','专注拼豆'],['view','⚙','视图设置']]
  const uniqueColors=useMemo(()=>{const map=new Map<string,PixelCell>();cells.forEach((item)=>map.set(item.code,item));return [...map.values()].slice(0,80)},[cells])
  return <View className='workbench-screen'>
    <View className='workbench-head'><Button onClick={onClose}>‹</Button><View><Text>拼豆工作台</Text><Text>{width} × {height} · {new Set(cells.map((item)=>item.code)).size} 色 · {width*height} 颗</Text></View><Button onClick={()=>Taro.showToast({title:'已撤销',icon:'none'})}>↶</Button><Button onClick={()=>Taro.showToast({title:'已重做',icon:'none'})}>↷</Button><Button className='export-btn' onClick={exportImage}>导出</Button></View>
    <View className='canvas-toolbar'><Button onClick={()=>setShowBrandPicker(true)}><Text>{brand.name}</Text><Text>{preset.label}⌄</Text></Button><View className='zoom-controls'><Button onClick={()=>setZoom((v)=>clamp(v/1.25,.35,40))}>−</Button><Text>{Math.round(zoom*100)}%</Text><Button onClick={()=>setZoom((v)=>clamp(v*1.25,.35,40))}>＋</Button></View></View>
    <InteractiveView className='work-canvas-wrap' onWheel={wheel} onTouchStart={touchStart} onTouchMove={touchMove} onTouchEnd={()=>panTouch.current=null} onMouseDown={mouseDown} onMouseMove={mouseMove} onMouseUp={()=>mouse.current=null} onMouseLeave={()=>mouse.current=null} onDoubleClick={()=>{setZoom(1);setPan({x:0,y:0})}}>
      <Canvas canvasId='workCanvas' id='workCanvas' className='work-canvas' style={{width:VIEW_W,height:VIEW_H}} disableScroll />
      {loading&&<View className='canvas-loading'><View/><Text>正在匹配真实品牌色号…</Text></View>}
    </InteractiveView>
    <View className='work-hint'>滚轮 / 双指缩放 · 拖动画布 · 双击恢复全图</View>
    {panel&&<View className='tool-panel'>
      <View className='tool-panel-head'><Text>{toolItems.find((item)=>item[0]===panel)?.[2]}</Text><Button onClick={()=>setPanel(null)}>完成</Button></View>
      {panel==='canvas'&&<View className='size-panel'><View><Text>宽度</Text><Input type='number' value={widthDraft} onInput={(e)=>setWidthDraft(e.detail.value)} onBlur={commitSize}/><Text>10–300</Text></View><View><Text>高度</Text><Input type='number' value={heightDraft} onInput={(e)=>setHeightDraft(e.detail.value)} onBlur={commitSize}/><Text>10–300</Text></View><Button onClick={commitSize}>应用尺寸</Button></View>}
      {panel==='image'&&<View className='image-panel'><View><Text>相似度阈值</Text><Text>{similarity}</Text></View><Slider min={0} max={100} value={similarity} activeColor='#18a99a' onChanging={(e)=>setSimilarity(e.detail.value)}/><View className='segmented'>{['主色','平均色','清晰轮廓'].map((item)=><Button key={item} className={pixelMode===item?'active':''} onClick={()=>setPixelMode(item)}>{item}</Button>)}</View></View>}
      {panel==='brush'&&<View className='brush-panel'><View className='segmented'>{['手型','画笔','橡皮'].map((item)=><Button key={item} className={tool===item?'active':''} onClick={()=>setTool(item)}>{item}</Button>)}</View><View className='brush-size'><Text>笔刷大小</Text>{[1,2,3,5].map((n)=><Button key={n} className={brushSize===n?'active':''} onClick={()=>setBrushSize(n)}>{n}</Button>)}</View></View>}
      {panel==='select'&&<ScrollView className='palette-strip' scrollX showScrollbar={false}><View>{uniqueColors.map((item)=><Button key={item.code} className={highlight===item.code?'active':''} onClick={()=>setHighlight(highlight===item.code?null:item.code)}><View style={{background:item.hex}}/><Text>{item.code}</Text></Button>)}</View></ScrollView>}
      {panel==='focus'&&<View className='focus-panel'><Text>专注模式会隐藏辅助信息，只保留当前拼豆区域。</Text><Button className={highlight?'active':''} onClick={()=>setHighlight(highlight?null:uniqueColors[0]?.code||null)}>{highlight?'关闭单色高亮':'开启单色高亮'}</Button></View>}
      {panel==='view'&&<View className='view-panel'><Button className={showGrid?'active':''} onClick={()=>setShowGrid(!showGrid)}>网格线</Button><Button className={showLabels?'active':''} onClick={()=>setShowLabels(!showLabels)}>格内色号</Button><Button className={showCoordinates?'active':''} onClick={()=>setShowCoordinates(!showCoordinates)}>坐标轴</Button><View><Text>粗线间隔</Text>{[5,10].map((n)=><Button key={n} className={gridInterval===n?'active':''} onClick={()=>setGridInterval(n)}>{n}</Button>)}</View></View>}
    </View>}
    <View className='work-tools'>{toolItems.map(([key,icon,label])=><Button key={key} className={panel===key?'active':''} onClick={()=>setPanel(panel===key?null:key)}><View>{icon}</View><Text>{label}</Text></Button>)}</View>
    {showBrandPicker&&<View className='work-picker-mask' onClick={()=>setShowBrandPicker(false)}><View className='work-brand-picker' onClick={(e)=>e.stopPropagation()}><View className='picker-handle'/><Text>选择品牌色板</Text><ScrollView className='work-brand-scroll' scrollY showScrollbar={false}><View className='work-brand-grid'>{COLOR_BRANDS.map((item)=><Button key={item.id} className={item.id===brandId?'active':''} onClick={()=>{setBrandId(item.id);setPresetId(item.presets[item.presets.length-1].id)}}>{item.name}</Button>)}</View><View className='work-presets'>{getBrand(brandId).presets.map((item)=><Button key={item.id} className={item.id===presetId?'active':''} onClick={()=>setPresetId(item.id)}><Text>{item.label}</Text><Text>{item.id===presetId?'✓':''}</Text></Button>)}</View></ScrollView><Button className='work-picker-confirm' onClick={()=>setShowBrandPicker(false)}>确认并重新匹配</Button></View></View>}
  </View>
}

export default function RecognitionFlow({source,onClose}:{source:string;onClose:()=>void}){
  const [crop,setCrop]=useState<CropBox|null>(null)
  return crop?<Workbench source={source} crop={crop} onClose={onClose}/>:<Cropper source={source} onCancel={onClose} onConfirm={setCrop}/>
}
