import { useEffect, useMemo, useState } from 'react'
import { Button, Input, ScrollView, Text, View } from '@tarojs/components'
import Taro from '@tarojs/taro'
import { COLOR_BRANDS, getBrand, getPalette, getPreset, seriesName, textColor, type PaletteColor } from '../data/palettes'
import './BeanWarehouse.scss'

type StockMap = Record<string, number>
type Screen = 'overview' | 'series' | 'shopping'

const STOCK_PREFIX = 'pixelhouse:stock:'
const DEFAULT_BRAND = 'mard'

function initialStock(colors: PaletteColor[]) {
  const result: StockMap = {}
  colors.forEach((color, index) => { result[color.code] = index % 17 === 0 ? 0 : 280 + ((index * 97) % 760) })
  return result
}

function loadStock(key: string, colors: PaletteColor[]) {
  try {
    const saved = Taro.getStorageSync<StockMap>(`${STOCK_PREFIX}${key}`)
    if (saved && typeof saved === 'object' && Object.keys(saved).length) return saved
  } catch { /* use local defaults */ }
  return initialStock(colors)
}

function StockTank({ ratio, total }: { ratio: number; total: number }) {
  const percent = Math.max(0, Math.min(100, Math.round(ratio * 100)))
  return <View className='stock-tank' aria-label={`实时库存 ${percent}%`}>
    <View className='tank-shadow' />
    <View className='tank-glass'>
      <View className='tank-liquid' style={{ height:`${Math.max(8, percent * .7)}%` }}><View /></View>
      <View className='tank-highlight' />
      <View className='tank-rim' />
    </View>
    <View className='tank-copy'><Text>{percent}%</Text><Text>{total.toLocaleString()} 颗</Text></View>
  </View>
}

export default function BeanWarehouse() {
  const [brandId, setBrandId] = useState(DEFAULT_BRAND)
  const defaultPresets = getBrand(DEFAULT_BRAND).presets
  const [presetId, setPresetId] = useState(defaultPresets[defaultPresets.length - 1].id)
  const [stock, setStock] = useState<StockMap>({})
  const [screen, setScreen] = useState<Screen>('overview')
  const [activeSeries, setActiveSeries] = useState('')
  const [query, setQuery] = useState('')
  const [showBrandPicker, setShowBrandPicker] = useState(false)
  const [editing, setEditing] = useState<PaletteColor | null>(null)
  const [draft, setDraft] = useState('0')

  const brand = getBrand(brandId)
  const preset = getPreset(brandId, presetId)
  const colors = useMemo(() => getPalette(preset.paletteIndex), [preset.paletteIndex])
  const storageKey = `${brand.id}:${preset.id}`

  useEffect(() => { setStock(loadStock(storageKey, colors)) }, [storageKey, colors])
  useEffect(() => {
    if (!Object.keys(stock).length) return
    try { Taro.setStorageSync(`${STOCK_PREFIX}${storageKey}`, stock) } catch { /* storage can be unavailable in preview */ }
  }, [stock, storageKey])

  const groups = useMemo(() => {
    const map = new Map<string, PaletteColor[]>()
    colors.forEach((color) => {
      const key = seriesName(color.code)
      map.set(key, [...(map.get(key) || []), color])
    })
    return [...map.entries()].sort(([a],[b]) => a.localeCompare(b, 'zh-CN', { numeric:true }))
  }, [colors])
  const currentColors = groups.find(([key]) => key === activeSeries)?.[1] || []
  const missing = colors.filter((color) => (stock[color.code] || 0) <= 0)
  const total = colors.reduce((sum, color) => sum + (stock[color.code] || 0), 0)
  const capacity = Math.max(1, colors.length * 1000)

  const patchStock = (codes: string[], value: number) => setStock((current) => {
    const next = { ...current }
    codes.forEach((code) => { next[code] = Math.max(0, Math.min(99999, value)) })
    return next
  })

  const chooseBrand = (nextBrandId: string) => {
    const nextBrand = getBrand(nextBrandId)
    setBrandId(nextBrand.id)
    setPresetId(nextBrand.presets[nextBrand.presets.length - 1].id)
  }

  const openSeries = (key: string) => { setActiveSeries(key); setScreen('series'); setQuery('') }
  const shownSeriesColors = currentColors.filter((color) => !query || color.code.toLowerCase().includes(query.toLowerCase()))
  const openEditor = (color: PaletteColor) => { setEditing(color); setDraft(String(stock[color.code] || 0)) }

  return <View className='warehouse'>
    <View className='warehouse-head'>
      {screen !== 'overview' && <Button className='warehouse-back' onClick={() => setScreen('overview')}>‹</Button>}
      <View><Text>{screen === 'shopping' ? '采购清单' : screen === 'series' ? activeSeries : '豆仓'}</Text><Text>{screen === 'overview' ? '按品牌与色号系列管理库存' : `${brand.name} · ${preset.label}`}</Text></View>
      {screen === 'overview' && <Button className='brand-switch' onClick={() => setShowBrandPicker(true)}><Text>{brand.name}</Text><Text>{preset.label}⌄</Text></Button>}
    </View>

    {screen === 'overview' && <ScrollView className='warehouse-scroll' scrollY enhanced showScrollbar={false}>
      <View className='warehouse-summary'>
        <StockTank ratio={total / capacity} total={total} />
        <View className='summary-copy'><Text>实时库存</Text><Text>{colors.length} 个色号</Text><Text>当前品牌所有库存变化会实时同步</Text></View>
      </View>
      <Button className={`stock-status ${missing.length ? 'danger' : 'healthy'}`} onClick={() => missing.length && setScreen('shopping')} disabled={!missing.length}>
        <View className='status-icon'>{missing.length ? '!' : '✓'}</View>
        <View><Text>{missing.length ? `需补充 ${missing.length} 种缺料` : '无需补充 · 库存充足'}</Text><Text>{missing.length ? '点击查看采购清单' : '当前全部色号均有库存'}</Text></View>
        {!!missing.length && <Text>›</Text>}
      </Button>
      <View className='warehouse-actions'>
        <Button onClick={() => setShowBrandPicker(true)}><View className='stack-icon'><View/><View/><View/></View><Text>切换色卡</Text><Text>{brand.name}</Text></Button>
        <Button onClick={() => setScreen('shopping')}><View className='box-icon'><View/></View><Text>采购清单</Text><Text>{missing.length ? `${missing.length} 项待补` : '无需补充'}</Text></Button>
      </View>
      <View className='series-heading'><Text>色号系列</Text><Text>按 ABC / 前缀排列</Text></View>
      <View className='series-grid'>{groups.map(([key, list]) => {
        const lack = list.filter((item) => !stock[item.code]).length
        return <Button key={key} onClick={() => openSeries(key)}>
          <View className='series-colors'>{list.slice(0,5).map((item) => <View key={item.code} style={{background:item.hex}} />)}</View>
          <Text>{key}</Text><Text>{list.length} 个色号</Text>{lack > 0 && <Text className='series-lack'>{lack} 缺</Text>}
        </Button>
      })}</View>
      <View className='warehouse-bottom-space' />
    </ScrollView>}

    {screen === 'series' && <ScrollView className='warehouse-scroll sub-screen' scrollY enhanced showScrollbar={false}>
      <View className='series-search'><Text>⌕</Text><Input value={query} placeholder='搜索此系列色号' onInput={(event) => setQuery(event.detail.value)} /></View>
      <View className='color-grid'>{shownSeriesColors.map((color) => <Button key={color.code} onClick={() => openEditor(color)}>
        <View className='color-dot' style={{background:color.hex,color:textColor(color.hex)}}>{color.code}</View>
        <Text>{color.code}</Text><Text>{stock[color.code] || 0} 颗</Text>
      </Button>)}</View>
      <View className='series-batch'>
        <Button onClick={() => patchStock(currentColors.map((color) => color.code), 1000)}>全部填满 1000 颗</Button>
        <Button onClick={() => Taro.showModal({title:'清空此盘',content:`确认清空 ${activeSeries} 全部库存？`,success:(res) => res.confirm && patchStock(currentColors.map((color) => color.code), 0)})}>清空此盘</Button>
      </View>
      <View className='warehouse-bottom-space' />
    </ScrollView>}

    {screen === 'shopping' && <ScrollView className='warehouse-scroll sub-screen shopping-screen' scrollY enhanced showScrollbar={false}>
      <View className={`shopping-banner ${missing.length ? '' : 'empty'}`}><Text>{missing.length ? `${missing.length} 个色号需要补充` : '库存充足'}</Text><Text>{missing.length ? '清单只统计库存为 0 的色号' : '当前没有需要采购的色号'}</Text></View>
      <View className='shopping-list'>{missing.map((color) => <View key={color.code}>
        <View className='shopping-swatch' style={{background:color.hex}} /><View><Text>{color.code}</Text><Text>{seriesName(color.code)} · 当前 0 颗</Text></View>
        <Button onClick={() => patchStock([color.code], 1000)}>补至 1000</Button>
      </View>)}</View>
      {!!missing.length && <Button className='fill-all-shopping' onClick={() => patchStock(missing.map((color) => color.code), 1000)}>全部补充至 1000 颗</Button>}
      <View className='warehouse-bottom-space' />
    </ScrollView>}

    {showBrandPicker && <View className='picker-mask' onClick={() => setShowBrandPicker(false)}>
      <View className='brand-picker' onClick={(event) => event.stopPropagation()}>
        <View className='picker-handle' /><Text className='picker-title'>选择品牌色号</Text><Text className='picker-sub'>12 个品牌 · 真实色号预设</Text>
        <ScrollView className='brand-list' scrollY enhanced showScrollbar={false}>
          <View className='brand-cards'>{COLOR_BRANDS.map((item) => <Button key={item.id} className={item.id === brandId ? 'active' : ''} onClick={() => chooseBrand(item.id)}>{item.name}</Button>)}</View>
          <Text className='preset-title'>{brand.name} 色板预设</Text>
          <View className='preset-cards'>{brand.presets.map((item) => <Button key={item.id} className={item.id === preset.id ? 'active' : ''} onClick={() => setPresetId(item.id)}><Text>{item.label}</Text><Text>{item.id === preset.id ? '已选择' : '使用此预设'}</Text></Button>)}</View>
        </ScrollView>
        <Button className='picker-confirm' onClick={() => setShowBrandPicker(false)}>确认使用</Button>
      </View>
    </View>}

    {editing && <View className='picker-mask' onClick={() => setEditing(null)}>
      <View className='stock-editor' onClick={(event) => event.stopPropagation()}>
        <View className='picker-handle' /><Text className='picker-title'>{editing.code} 库存调整</Text>
        <View className='editor-preview'><View style={{background:editing.hex}} /><View><Text>{editing.code}</Text><Text>实时预览库存数量</Text></View><Text>{Math.max(0, Number(draft) || 0)} 颗</Text></View>
        <View className='editor-controls'>
          <Button onClick={() => setDraft(String(Math.max(0, (Number(draft)||0) - 100)))}>-100</Button>
          <Input type='number' value={draft} onInput={(event) => setDraft(event.detail.value)} />
          <Button onClick={() => setDraft(String((Number(draft)||0) + 100))}>+100</Button>
        </View>
        <Button className='editor-save' onClick={() => { patchStock([editing.code], Number(draft)||0); setEditing(null) }}>确定保存</Button>
      </View>
    </View>}
  </View>
}
