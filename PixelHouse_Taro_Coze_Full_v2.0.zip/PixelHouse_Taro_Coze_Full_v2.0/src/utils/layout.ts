import Taro from '@tarojs/taro'

export type FrameLayout = {
  scale: number
  offsetX: number
  topInset: number
  shellHeight: number
  deviceMode: 'phone' | 'tablet' | 'desktop'
}

export function calculateFrameLayout(): FrameLayout {
  const win = Taro.getWindowInfo ? Taro.getWindowInfo() : Taro.getSystemInfoSync()
  const device = Taro.getDeviceInfo ? Taro.getDeviceInfo() : Taro.getSystemInfoSync()
  const width = win.windowWidth || 390
  const height = win.windowHeight || 844
  const screenWidth = win.screenWidth || width
  const screenHeight = win.screenHeight || height
  const shortSide = Math.min(screenWidth, screenHeight)
  const platform = String(device.platform || '').toLowerCase()
  const deviceType = String(('deviceType' in device ? device.deviceType : '') || '').toLowerCase()
  const desktop = deviceType === 'pc' || ['windows', 'mac', 'macos', 'devtools'].includes(platform)
  const tablet = !desktop && (deviceType === 'pad' || deviceType === 'tablet' || shortSide >= 600)
  const landscape = width > height
  const safeBottom = win.safeArea ? Math.max(0, screenHeight - win.safeArea.bottom) : 0
  const topInset = Math.max(0, win.statusBarHeight || 0)
  let targetWidth = width

  if ((tablet || desktop) && width >= 600) {
    targetWidth = Math.min(desktop ? 480 : 520, width - 48)
  }

  if (landscape) {
    const availableHeight = Math.max(320, height - topInset - safeBottom - 16)
    targetWidth = Math.min(targetWidth, Math.max(Math.min(320, width), availableHeight * 390 / 844))
  }

  targetWidth = Math.max(1, Math.min(width, targetWidth))
  const scale = targetWidth / width
  const offsetX = Math.max(0, (width - targetWidth) / 2)
  const shellHeight = Math.max(height, topInset + targetWidth * 844 / 390)

  return {
    scale,
    offsetX,
    topInset,
    shellHeight,
    deviceMode: desktop ? 'desktop' : tablet ? 'tablet' : 'phone'
  }
}
