import rawColorMap from './brand-color-map.json'

export type PaletteColor = { key: string; code: string; hex: string }
export type PalettePreset = { id: string; label: string; paletteIndex: string; expected: number }
export type ColorBrand = { id: string; name: string; presets: PalettePreset[] }

export const COLOR_BRANDS: ColorBrand[] = [
  { id: 'mard', name: 'MARD', presets: [24,48,72,96,120,144,221,264,291].map((n, i) => ({ id:`mard-${n}`, label:`${n} 色预设`, paletteIndex:String(i + 1), expected:n })) },
  { id: 'huangdoudou', name: '黄豆豆', presets: [24,48,72,96,120,144,168].map((n, i) => ({ id:`huang-${n}`, label:`${n} 色预设`, paletteIndex:String(i + 10), expected:n })) },
  { id: 'dodo', name: 'DoDo', presets: [{ id:'dodo-288', label:'288 色预设', paletteIndex:'17', expected:288 }] },
  { id: 'coco', name: 'COCO', presets: [24,48,72,96,120,144,168,192,216,291].map((n, i) => ({ id:`coco-${n}`, label:`${n} 色预设`, paletteIndex:String(i + 18), expected:n })) },
  { id: 'manman', name: '漫漫', presets: [24,48,72,96,120,144,168,192,221,291].map((n, i) => ({ id:`manman-${n}`, label:`${n} 色预设`, paletteIndex:String(i + 28), expected:n })) },
  { id: 'xiaowu', name: '小舞', presets: [{ id:'xiaowu-291', label:'291 色预设', paletteIndex:'38', expected:291 }] },
  { id: 'mixiaowo', name: '咪小窝', presets: [{ id:'mixiaowo-291', label:'291 色预设', paletteIndex:'39', expected:291 }] },
  { id: 'kaka', name: '卡卡', presets: [{ id:'kaka-230', label:'230 色预设', paletteIndex:'40', expected:230 }] },
  { id: 'youken', name: '优肯', presets: [
    { id:'youken-171', label:'5mm · 171 色', paletteIndex:'44', expected:171 },
    { id:'youken-197', label:'197 色预设', paletteIndex:'43', expected:197 },
    { id:'youken-418', label:'418 色预设', paletteIndex:'431', expected:418 }
  ]},
  { id: 'shishi', name: '柿柿', presets: [{ id:'shishi-286', label:'286 色预设', paletteIndex:'42', expected:286 }] },
  { id: 'tongqu', name: '童趣', presets: [{ id:'tongqu-217', label:'217 色预设', paletteIndex:'45', expected:217 }] },
  { id: 'panpan', name: '盼盼', presets: [{ id:'panpan-291', label:'291 色预设', paletteIndex:'41', expected:291 }] }
]

type RawMap = Record<string, Record<string, string>>

const cache = new Map<string, PaletteColor[]>()

export function getPalette(paletteIndex: string): PaletteColor[] {
  const cached = cache.get(paletteIndex)
  if (cached) return cached
  const seen = new Set<string>()
  const result: PaletteColor[] = []
  Object.entries(rawColorMap as RawMap).forEach(([hex, codes]) => {
    const code = codes[paletteIndex]
    if (!code || seen.has(code)) return
    seen.add(code)
    result.push({ key:`${paletteIndex}:${code}`, code, hex })
  })
  result.sort((a, b) => a.code.localeCompare(b.code, 'zh-CN', { numeric:true }))
  cache.set(paletteIndex, result)
  return result
}

export function getBrand(id: string) {
  return COLOR_BRANDS.find((brand) => brand.id === id) || COLOR_BRANDS[0]
}

export function getPreset(brandId: string, presetId?: string) {
  const brand = getBrand(brandId)
  return brand.presets.find((preset) => preset.id === presetId) || brand.presets[brand.presets.length - 1]
}

export function seriesName(code: string) {
  const upper = code.toUpperCase()
  const prefix = upper.match(/^[A-Z]+/)?.[0]
  if (prefix) return `${prefix} 系列`
  const number = Number(upper.match(/\d+/)?.[0] || 0)
  if (number <= 20) return '1–20'
  if (number <= 50) return '21–50'
  if (number <= 100) return '51–100'
  if (number <= 200) return '101–200'
  return '200+'
}

export function textColor(hex: string) {
  const value = hex.replace('#', '')
  const r = parseInt(value.slice(0,2), 16)
  const g = parseInt(value.slice(2,4), 16)
  const b = parseInt(value.slice(4,6), 16)
  return (r * 299 + g * 587 + b * 114) / 1000 > 150 ? '#2e2924' : '#ffffff'
}
