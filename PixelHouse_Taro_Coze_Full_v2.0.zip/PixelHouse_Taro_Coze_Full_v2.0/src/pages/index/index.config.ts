export default definePageConfig({
  navigationStyle: 'custom',
  pageOrientation: 'auto',
  disableScroll: false
})
