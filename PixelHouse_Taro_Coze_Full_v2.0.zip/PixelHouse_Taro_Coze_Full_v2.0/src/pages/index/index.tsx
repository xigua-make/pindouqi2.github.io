import { useEffect, useMemo, useState } from 'react'
import { Button, Image, Input, Text, View } from '@tarojs/components'
import Taro from '@tarojs/taro'
import BottomNav, { type PageKey } from '../../components/BottomNav'
import { calculateFrameLayout, type FrameLayout } from '../../utils/layout'
import appIcon from '../../assets/app-icon.png'
import BeanWarehouse from '../../features/BeanWarehouse'
import RecognitionFlow from '../../features/RecognitionFlow'
import './index.scss'

type FilterKey = 'featured' | 'original' | 'free' | 'favorite' | 'all'
type Pattern = {
  id: number
  title: string
  author: string
  meta: string
  featured: boolean
  original: boolean
  free: boolean
  colors: string[]
}

const beadColors = ['gold','coral','deep','teal','mint','deep','teal','coral','gold','mint','deep','teal','coral']
const patterns: Pattern[] = [
  { id:1,title:'治愈小屋',author:'像素小鹿',meta:'48×48 · 免费',featured:true,original:true,free:true,colors:beadColors },
  { id:2,title:'复古花束',author:'花花手作',meta:'48×48 · 12豆',featured:true,original:true,free:false,colors:['gold','deep','coral','teal','mint','gold','deep','teal','coral','mint','gold','teal'] },
  { id:3,title:'像素猫咪',author:'猫爪社',meta:'48×48 · 会员',featured:true,original:false,free:false,colors:['deep','mint','coral','deep','gold','mint','teal','coral','deep','mint','gold','teal'] },
  { id:4,title:'海边日落',author:'橘子海',meta:'48×48 · 18豆',featured:true,original:true,free:false,colors:['coral','gold','coral','teal','gold','deep','teal','coral','gold','deep','teal','mint'] },
  { id:5,title:'森林蘑菇',author:'森系手作',meta:'32×32 · 免费',featured:false,original:true,free:true,colors:['coral','deep','mint','gold','coral','deep','teal','mint','deep','gold','coral','teal'] },
  { id:6,title:'星空鲸鱼',author:'蓝色宇宙',meta:'64×64 · 22豆',featured:false,original:true,free:false,colors:['deep','teal','mint','deep','gold','teal','deep','mint','coral','deep','teal','gold'] },
  { id:7,title:'草莓蛋糕',author:'甜点像素',meta:'40×40 · 免费',featured:false,original:false,free:true,colors:['coral','mint','gold','coral','deep','mint','coral','gold','teal','mint','coral','gold'] },
  { id:8,title:'幸运锦鲤',author:'一颗彩豆',meta:'56×56 · 16豆',featured:false,original:true,free:false,colors:['coral','gold','mint','deep','coral','gold','teal','coral','gold','deep','mint','coral'] }
]

const beans = [
  ['A1','#fff4a8','320'],['A2','#ffc85b','357'],['A3','#ff8a65','394'],['A4','#ef5350','0'],['A5','#e57373','468'],
  ['A6','#c5e1a5','505'],['A7','#7ed957','542'],['A8','#43c6ac','579'],['A9','#168c7d','616'],['A10','#b2dfdb','653'],
  ['A11','#5c6bc0','690'],['A12','#42a5f5','727'],['A13','#26c6da','764'],['A14','#263238','0'],['A15','#8d6e63','838'],
  ['A16','#ab47bc','875'],['A17','#ec407a','912'],['A18','#ff7043','949'],['A19','#9ccc65','986'],['A20','#7e57c2','1023'],
  ['A21','#26a69a','1060'],['A22','#78909c','1097'],['A23','#f06292','1134'],['A24','#29b6f6','1171'],['A25','#8bc34a','1208']
]

function toast(title: string) {
  Taro.showToast({ title, icon: 'none' })
}

function PixelPattern({ colors = beadColors, small = false }: { colors?: string[]; small?: boolean }) {
  return <View className={`pixel-pattern ${small ? 'small' : ''}`}>{colors.map((color, i) => <View key={`${color}-${i}`} className={`bead ${color}`} />)}</View>
}

function PageHeader({ title, sub }: { title: string; sub: string }) {
  return <><Text className='page-title'>{title}</Text><Text className='page-sub'>{sub}</Text></>
}

function ToolboxPage({ onCreate }: { onCreate: () => void }) {
  return <>
    <Text className='brand'>像素屋</Text>
    <Text className='toolbox-title'>今天想创造什么？</Text>
    <Text className='toolbox-sub'>把灵感变成一张可以拼出来的图纸</Text>
    <Button className='toolbox-hero' onClick={onCreate}>
      <Text className='hero-title'>导入图片</Text>
      <Text className='hero-sub'>智能识别颜色 · 自动匹配豆号</Text>
      <Text className='hero-action'>开始创作</Text>
      <PixelPattern small />
    </Button>
    <Text className='section-title tools-title'>常用工具</Text>
    <View className='tool-row'>
      {[
        ['ai','AI生成','AI生成图纸'],
        ['photo','图片直接识别','原图直接生成'],
        ['draw','自由绘制','编辑每个像素']
      ].map((tool) => <Button key={tool[1]} className='tool-card' onClick={onCreate}>
        <View className={`tool-icon ${tool[0]}`}><View className={`art art-${tool[0]}`} /></View>
        <Text className='tool-name'>{tool[1]}</Text><Text className='tool-copy'>{tool[2]}</Text>
      </Button>)}
    </View>
    <Text className='section-title recent-title'>最近项目</Text>
    <Button className='recent-card' onClick={() => toast('继续编辑：花园小屋')}>
      <View className='recent-preview'><PixelPattern /></View>
      <View className='recent-info'><Text className='recent-name'>花园小屋</Text><Text className='recent-meta'>48×48 · 18色</Text><Text className='recent-link'>继续编辑 →</Text></View>
    </Button>
    <View className='daily-card'><View><Text>每日进度</Text><Text>连续创作 3 天</Text></View><View className='daily-track'><View /></View></View>
  </>
}

function HomePage({ onBack, onRecognize }: { onBack: () => void; onRecognize: () => void }) {
  const tools = [
    ['AI 转像素图','描述想法或上传图片，生成可编辑拼豆图纸'],
    ['图片直接识别','自动识别轮廓、颜色与豆子色号'],
    ['自由画图','在网格画布中自由创作'],
    ['二维码生成','文字或链接生成拼豆二维码']
  ]
  return <>
    <Button className='back-btn' onClick={onBack}><View className='back-chevron' /></Button>
    <Text className='create-title'>开始创作</Text><Text className='create-sub'>选择一种方式，让灵感变成像素图</Text>
    <View className='brand-badge'><View /><View /><View /><Text>像素屋</Text></View>
    <Button className='ai-card' onClick={() => toast(tools[0][0])}>
      <Text className='ai-badge'>✦ AI 推荐</Text><Text className='ai-title'>AI 转像素图</Text><Text className='ai-copy'>描述想法或上传图片，生成可编辑拼豆图纸</Text>
      <View className='ai-chips'><Text>智能减色</Text><Text>自动配豆</Text><Text>高清导出</Text></View>
      <Text className='ai-action'>立即生成　→</Text>
      <View className='ai-preview'><Text>PIXEL AI</Text><PixelPattern small /><View className='mini-progress'><View /></View></View>
    </Button>
    <Button className='recognize-card' onClick={onRecognize}>
      <View className='feature-icon teal'><View className='art art-recognition' /></View>
      <View className='recognize-info'><Text className='feature-title'>图片直接识别</Text><Text className='feature-copy'>自动识别轮廓、颜色与豆子色号</Text><Text className='feature-tag'>智能校色</Text></View>
      <View className='forward'><View /></View>
    </Button>
    <View className='create-dual'>
      <Button onClick={() => toast(tools[2][0])}><View className='feature-icon blue'><View className='art art-draw' /></View><Text className='dual-title'>自由画图</Text><Text className='dual-copy'>在网格画布中自由创作</Text></Button>
      <Button onClick={() => toast(tools[3][0])}><View className='feature-icon purple'><View className='art art-qr' /></View><Text className='dual-title'>二维码生成</Text><Text className='dual-copy'>文字或链接生成拼豆二维码</Text></Button>
    </View>
    <View className='save-notice'><View className='cloud'>☁</View><View><Text>创作记录自动保存</Text><Text>随时返回继续编辑，不丢失灵感</Text></View><Text>已开启</Text></View>
  </>
}

function GalleryPage() {
  const [query, setQuery] = useState('')
  const [filter, setFilter] = useState<FilterKey>('featured')
  const [favorites, setFavorites] = useState<number[]>([2])

  const visible = useMemo(() => {
    const keyword = query.trim().toLowerCase()
    return patterns.filter((pattern) => {
      const matchesQuery = !keyword || `${pattern.title}${pattern.author}${pattern.meta}`.toLowerCase().includes(keyword)
      const matchesFilter = filter === 'all' ||
        (filter === 'featured' && pattern.featured) ||
        (filter === 'original' && pattern.original) ||
        (filter === 'free' && pattern.free) ||
        (filter === 'favorite' && favorites.includes(pattern.id))
      return matchesQuery && matchesFilter
    }).slice(0, filter === 'all' || query ? 8 : 4)
  }, [query, filter, favorites])

  const toggleFavorite = (id: number) => {
    setFavorites((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id])
  }

  return <>
    <PageHeader title='图纸广场' sub='发现灵感，收藏喜欢的拼豆图纸' />
    <View className='gallery-search'><Text>⌕</Text><Input value={query} placeholder='搜索图纸、作者或标签' onInput={(event) => setQuery(event.detail.value)} confirmType='search' /></View>
    <View className='gallery-filters'>
      {([['featured','精选'],['original','原创'],['free','免费'],['favorite','收藏']] as Array<[FilterKey,string]>).map(([key,label]) =>
        <Button key={key} className={filter === key ? 'active' : ''} onClick={() => setFilter(key)}>{label}</Button>)}
    </View>
    {visible.length ? <View className='pattern-grid'>{visible.map((pattern) =>
      <View key={pattern.id} className='pattern-card' onClick={() => Taro.showModal({ title: pattern.title, content: `${pattern.author} · ${pattern.meta}\n图纸详情功能待接入`, showCancel: false })}>
        <View className='pattern-preview'><PixelPattern colors={pattern.colors} /></View>
        <Text className='pattern-name'>{pattern.title}</Text><Text className='pattern-meta'>{pattern.meta}</Text>
        <Button className={`favorite ${favorites.includes(pattern.id) ? 'selected' : ''}`} onClick={(event) => { event.stopPropagation(); toggleFavorite(pattern.id) }}>♥</Button>
      </View>)}</View>
      : <View className='empty-result'><Text>没有找到相关图纸</Text><Button onClick={() => { setQuery(''); setFilter('featured') }}>清除筛选</Button></View>}
    <Button className='gallery-tip' onClick={() => { setFilter('all'); setQuery(''); toast('已显示全部图纸') }}><Text>本周精选 · 24 张新图纸</Text><Text>查看全部 →</Text></Button>
  </>
}

function BeansPage() {
  const [filter, setFilter] = useState('全部')
  const [query, setQuery] = useState('')
  const visibleBeans = beans.filter((bean) => !query || bean[0].toLowerCase().includes(query.toLowerCase()))
  return <>
    <PageHeader title='豆仓' sub='管理豆色库存，缺色及时补充' />
    <View className='bean-overview'>{[['295','色号'],['23860','总量'],['8','偏低'],['3','缺货']].map((item,i)=><View key={item[1]} className={`v${i}`}><Text>{item[0]}</Text><Text>{item[1]}</Text></View>)}</View>
    <View className='bean-search'><Text>⌕</Text><Input value={query} placeholder='搜索色号 / 名称' onInput={(event)=>setQuery(event.detail.value)} /></View>
    <Button className='batch-btn' onClick={() => toast('批量管理待接入')}>批量</Button>
    <View className='bean-filters'>{['全部','常用','不足','夜光','珠光'].map((item)=><Button key={item} className={filter===item?'active':''} onClick={()=>setFilter(item)}>{item}</Button>)}</View>
    <View className='bean-grid'>{visibleBeans.map((bean)=><Button key={bean[0]} style={{background:bean[1]}} className={bean[0]==='A14'?'dark':''} onClick={()=>toast(`${bean[0]} 库存 ${bean[2]}`)}><Text>{bean[0]}</Text><Text>{bean[2]}</Text></Button>)}</View>
    <View className='stock-alert'>3 个色号缺货，建议立即补货</View>
  </>
}

function ProfilePage({ onCreate }: { onCreate: () => void }) {
  const stats = [['12','作品'],['3','草稿'],['8','收藏'],['24','导出']]
  const creationTools = [['ai','AI 创作'],['photo','图片识别'],['draw','自由画图'],['qr','二维码']]
  const services = [['works','▦','我的作品'],['record','◷','创作记录'],['help','?','帮助反馈'],['setting','⚙','系统设置']]
  return <>
    <PageHeader title='我的' sub='账户、会员权益与创作资产' />
    <Button className='settings' onClick={()=>toast('系统设置')}><Text>⚙</Text></Button>
    <View className='member-card'>
      <View className='avatar'><Image src={appIcon} mode='aspectFill' /></View>
      <View className='member-sparkles'><View /><View /><View /><View /></View>
      <View className='member-info'><Text>liujin778240</Text><Text>PIXEL MEMBER</Text><Text>像素创作账户 · 普通会员</Text><Button onClick={()=>toast('会员功能待接入')}>升级黄金会员</Button></View>
      <View className='member-progress'><Text>距离黄金会员还差 1280 积分</Text><View><View /></View></View>
    </View>
    <View className='profile-stats'>{stats.map((stat,i)=><View key={stat[1]} className={`stat-${i}`}><View /><Text>{stat[0]}</Text><Text>{stat[1]}</Text></View>)}</View>
    <View className='creation-hub'>
      <View className='hub-head'><Text>创作中心</Text><Text>继续上次创作 ›</Text></View>
      <View className='hub-tools'>{creationTools.map((tool)=><Button key={tool[1]} onClick={onCreate}><View className={`hub-icon ${tool[0]}`}><View className={`art art-${tool[0]}`} /></View><Text>{tool[1]}</Text></Button>)}</View>
    </View>
    <Text className='service-title'>常用服务</Text>
    <View className='services'>{services.map((service)=><Button key={service[2]} onClick={()=>toast(service[2])}><View className={`service-icon ${service[0]}`}>{service[1]}</View><Text>{service[2]}</Text><Text>›</Text></Button>)}</View>
  </>
}

export default function IndexPage() {
  const [page, setPage] = useState<PageKey>('toolbox')
  const [recognitionSource, setRecognitionSource] = useState('')
  const [layout, setLayout] = useState<FrameLayout>(() => calculateFrameLayout())

  useEffect(() => {
    const update = () => setLayout(calculateFrameLayout())
    update()
    Taro.onWindowResize?.(update)
    return () => Taro.offWindowResize?.(update)
  }, [])

  const go = (next: PageKey) => {
    setPage(next)
    Taro.pageScrollTo?.({ scrollTop: 0, duration: 0 })
  }

  const startRecognition = async () => {
    try {
      const result = await Taro.chooseImage({ count: 1, sourceType: ['album', 'camera'], sizeType: ['original', 'compressed'] })
      const path = result.tempFilePaths?.[0]
      if (path) setRecognitionSource(path)
    } catch (error) {
      if ((error as Error)?.message && !String((error as Error).message).includes('cancel')) toast('未能读取图片，请重试')
    }
  }

  const canvasStyle = {
    marginLeft: `${layout.offsetX}px`,
    marginTop: `${layout.topInset}px`,
    transform: `scale(${layout.scale})`,
    transformOrigin: 'left top'
  }

  return <View className={`app-shell device-${layout.deviceMode}`} style={{ minHeight: `${layout.shellHeight}px` }}>
    <View className={`design-canvas page-${page}`} style={canvasStyle}>
      {page === 'toolbox' && <ToolboxPage onCreate={() => go('home')} />}
      {page === 'gallery' && <GalleryPage />}
      {page === 'home' && <HomePage onBack={() => go('toolbox')} onRecognize={startRecognition} />}
      {page === 'beans' && <BeanWarehouse />}
      {page === 'profile' && <ProfilePage onCreate={() => go('home')} />}
      {!recognitionSource && <BottomNav active={page} onChange={go} />}
      {!!recognitionSource && <RecognitionFlow source={recognitionSource} onClose={() => setRecognitionSource('')} />}
    </View>
  </View>
}
