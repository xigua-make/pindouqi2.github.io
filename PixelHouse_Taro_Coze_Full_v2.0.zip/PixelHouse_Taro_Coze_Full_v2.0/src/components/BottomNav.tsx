import { Button, Image, Text, View } from '@tarojs/components'
import navToolbox from '../assets/nav-home.png'
import navGallery from '../assets/nav-gallery.png'
import navBeans from '../assets/nav-beans.png'
import navProfile from '../assets/nav-profile.png'
import './BottomNav.scss'

export type PageKey = 'toolbox' | 'gallery' | 'home' | 'beans' | 'profile'

type Props = {
  active: PageKey
  onChange: (page: PageKey) => void
}

const items: Array<{ key: PageKey; label: string; icon?: string }> = [
  { key: 'toolbox', label: '工具箱', icon: navToolbox },
  { key: 'gallery', label: '图纸广场', icon: navGallery },
  { key: 'home', label: '首页' },
  { key: 'beans', label: '豆仓', icon: navBeans },
  { key: 'profile', label: '我的', icon: navProfile }
]

export default function BottomNav({ active, onChange }: Props) {
  return (
    <View className='bottom-nav'>
      <View className='nav-glass-line' />
      {items.map((item) => (
        <Button
          key={item.key}
          className={`nav-item ${active === item.key ? 'active' : ''}`}
          onClick={() => onChange(item.key)}
        >
          <View className='nav-icon'>
            {item.icon
              ? <Image src={item.icon} mode='aspectFit' />
              : <View className='home-3d'><View className='home-roof' /><View className='home-body'><View /></View></View>}
          </View>
          <Text className='nav-label'>{item.label}</Text>
          {active === item.key && <View className='nav-dot' />}
        </Button>
      ))}
    </View>
  )
}
