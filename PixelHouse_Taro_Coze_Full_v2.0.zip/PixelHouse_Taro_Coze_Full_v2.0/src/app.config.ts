export default defineAppConfig({
  pages: ['pages/index/index'],
  window: {
    navigationStyle: 'custom',
    backgroundColor: '#f7f3ea',
    backgroundTextStyle: 'dark'
  }
})
