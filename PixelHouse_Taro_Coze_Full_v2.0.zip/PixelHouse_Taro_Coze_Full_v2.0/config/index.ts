import { defineConfig, type UserConfigExport } from '@tarojs/cli'
import devConfig from './dev'
import prodConfig from './prod'

export default defineConfig<'webpack5'>(async (merge) => {
  const baseConfig: UserConfigExport<'webpack5'> = {
    projectName: 'pixelhouse',
    date: '2026-08-15',
    designWidth: 390,
    deviceRatio: {
      390: 750 / 390
    },
    sourceRoot: 'src',
    outputRoot: `dist/${process.env.TARO_ENV || 'h5'}`,
    framework: 'react',
    compiler: 'webpack5',
    cache: { enable: true },
    plugins: [],
    mini: {
      postcss: {
        pxtransform: { enable: true },
        cssModules: { enable: false }
      }
    },
    h5: {
      publicPath: '/',
      staticDirectory: 'static',
      postcss: {
        autoprefixer: { enable: true },
        cssModules: { enable: false }
      }
    }
  }

  return process.env.NODE_ENV === 'development'
    ? merge({}, baseConfig, devConfig)
    : merge({}, baseConfig, prodConfig)
})
